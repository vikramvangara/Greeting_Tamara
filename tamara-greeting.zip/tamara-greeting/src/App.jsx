import { useState } from "react";

export default function App() {
  const [quote, setQuote] = useState("");

  const goodQuotes = [
    "You're doing amazing—keep the momentum going!",
    "Small wins add up to big results. Nice work!",
    "Today is a great day to build something awesome.",
    "Confidence comes from showing up. You're showing up!",
  ];

  const toughDayQuotes = [
    "It's okay to have off days. You’ve got this.",
    "One step at a time—progress over perfection.",
    "Be gentle with yourself. Better days are coming.",
    "Storms pass. Your strength won’t.",
  ];

  function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      minHeight: "100vh",
      width: "100vw",
      background: "#a4a7aaff",
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
      padding: 24,
      margin: 0,
      position: "fixed",
      top: 0,
      left: 0
    }}>
      <div style={{
        width: "100%",
        maxWidth: 720,
        background: "white",
        borderRadius: 16,
        boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
        padding: 28
      }}>
        <h1 style={{ fontSize: 32, margin: 0 }}>Good morning, Tamara!</h1>
        <p style={{ fontSize: 18, marginTop: 8, color: "#4a5568" }}>
          How are you doing today?
        </p>

        <div style={{ display: "flex", gap: 12, marginTop: 20, flexWrap: "wrap" }}>
          <button
            onClick={() => setQuote(pickRandom(goodQuotes))}
            style={{
              padding: "10px 16px",
              borderRadius: 999,
              border: "1px solid #e2e8f0",
              background: "#edf2f7",
              cursor: "pointer",
              fontSize: 16
            }}
          >
            Good
          </button>

          <button
            onClick={() => setQuote(pickRandom(toughDayQuotes))}
            style={{
              padding: "10px 16px",
              borderRadius: 999,
              border: "1px solid #e2e8f0",
              background: "#ffe8e8",
              cursor: "pointer",
              fontSize: 16
            }}
          >
            Not that Good
          </button>
        </div>

        {quote && (
          <div style={{
            marginTop: 22,
            padding: 16,
            background: "#f7fafc",
            border: "1px solid #e2e8f0",
            borderRadius: 12,
            lineHeight: 1.5,
            color: "#2d3748",
            fontSize: 18
          }}>
            {quote}
          </div>
        )}
      </div>
    </div>
  );
}
